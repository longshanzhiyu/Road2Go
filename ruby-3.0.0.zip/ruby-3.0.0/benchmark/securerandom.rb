require "securerandom"

20_0000.times do
  SecureRandom.random_number(100)
end
